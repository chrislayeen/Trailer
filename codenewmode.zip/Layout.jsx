import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useSession } from '../context/SessionContext';
import LanguageSwitcher from './LanguageSwitcher';
import { LogOut, LayoutDashboard } from 'lucide-react';

import { useAuth } from '../context/AuthContext';

const Layout = ({ children }) => {
    const { driverName, isAdmin, logoutDriver } = useSession();
    const { signOut } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const { t } = useTranslation();

    const isQrScreen = location.pathname === '/';
    const isScanner = location.pathname === '/scanner';
    const isAdminRoute = location.pathname.startsWith('/admin');

    const handleLogout = () => {
        if (isAdminRoute) {
            signOut();
            navigate('/admin/login');
        } else {
            logoutDriver();
            navigate('/');
        }
    };

    const handleAdminLink = () => {
        navigate('/admin');
    }

    return (
        <div className="layout" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
            {!isScanner && (
                <header style={{
                    backgroundColor: 'var(--color-white)',
                    color: 'var(--slate-900)',
                    padding: '1rem',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    borderBottom: '1px solid var(--color-gray-200)',
                    position: 'sticky',
                    top: 0,
                    zIndex: 10
                }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        {/* Simulated Back button if not home, for visual completeness matching design */}
                        {!isQrScreen && <button style={{ background: 'none', border: 'none', padding: 0, marginRight: '8px' }} onClick={() => navigate(-1)}><div style={{ width: '24px', height: '24px', borderRadius: '50%', background: '#eff6ff', color: 'var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>‹</div></button>}
                        <h1 style={{ fontSize: '1.1rem', fontWeight: 600 }}>{t('app.header_title')}</h1>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                        <LanguageSwitcher />

                        {driverName && !isAdminRoute && (
                            <span style={{ fontSize: '0.9rem', color: 'var(--primary)', fontWeight: 500 }}>
                                {driverName}
                            </span>
                        )}

                        {(driverName || isAdmin) && !isQrScreen && (
                            <button
                                onClick={handleLogout}
                                style={{
                                    background: '#fef2f2',
                                    color: '#b91c1c',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    cursor: 'pointer',
                                    border: '1px solid #fee2e2',
                                    width: '38px',
                                    height: '38px',
                                    borderRadius: '50%',
                                    fontSize: '0.85rem',
                                    fontWeight: 600,
                                    transition: 'all 0.2s'
                                }}
                                title={t('app.logout')}
                            >
                                <LogOut size={18} />
                            </button>
                        )}
                    </div>
                </header>
            )}

            <main style={{ flex: 1, width: '100%', maxWidth: isScanner ? '100%' : '600px', padding: isScanner ? 0 : '1rem', margin: '0 auto', position: 'relative' }}>
                {children}
            </main>
        </div>
    );
};

export default Layout;
